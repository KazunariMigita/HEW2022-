<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>プライバシーポリシー</title>
</head>
<body>
    <div class="content">

        <h2>プライバシーポリシーとセキュリティー</h2>
        <p></p>
        
        <div class="botton">
            <a href=""><button>同意する</button></a>
            <a href="../index.php"><button>同意しない</button></a>
        </div>

    </div>
</body>
</html>